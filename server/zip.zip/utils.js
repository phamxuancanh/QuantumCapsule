const API_PREFIX = '/api/v1'
module.exports = { API_PREFIX }
